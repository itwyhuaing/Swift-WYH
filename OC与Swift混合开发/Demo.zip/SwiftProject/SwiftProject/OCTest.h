//
//  OCTest.h
//  SwiftProject
//
//  Created by hnbwyh on 2017/11/24.
//  Copyright © 2017年 ZhiXingJY. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OCTest : NSObject

- (void)logWithMessage:(NSString *)msg index:(NSInteger)idx;

@end
