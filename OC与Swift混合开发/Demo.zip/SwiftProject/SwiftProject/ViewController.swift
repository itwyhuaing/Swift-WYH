//
//  ViewController.swift
//  SwiftProject
//
//  Created by hnbwyh on 2017/11/24.
//  Copyright © 2017年 ZhiXingJY. All rights reserved.
//
/**
 https://developer.apple.com/library/content/documentation/Swift/Conceptual/BuildingCocoaApps/MixandMatch.html#//apple_ref/doc/uid/TP40014216-CH10-XID_78
 **/
import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let t:OCTest = OCTest()
        t.log(withMessage: "OC 方法", index: 8)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

