//
//  Test.swift
//  OCProject
//
//  Created by hnbwyh on 2017/11/24.
//  Copyright © 2017年 ZhiXingJY. All rights reserved.
//

import UIKit

public class Test: NSObject {

    public func log(msg:String) {
        print("这是Swift的方法")
    }
    
}


public func globalLog(msg:String,name:String) {
    print("这是Swift全局的log方法")
}
