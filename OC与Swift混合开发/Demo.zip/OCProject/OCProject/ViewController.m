//
//  ViewController.m
//  OCProject
//
//  Created by hnbwyh on 2017/11/24.
//  Copyright © 2017年 ZhiXingJY. All rights reserved.
//

/**
 http://mengxiangyue.com/2016/01/11/OC项目中使用Swift/
 **/


#import "ViewController.h"
#import "OCProject-Swift.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    Test *t = [[Test alloc] init];
    [t logWithMsg:@"测试数据信息"];
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    SWFirstVC *vc = [[SWFirstVC alloc] init];
    [self.navigationController pushViewController:vc animated:TRUE];
    
}



@end
